<?php get_header(); ?>
<section class='cd-main-content cd-projects'>
    <?php get_template_part('includes/sections/page-blog/top-screen')?>
    <?php get_template_part('includes/sections/page-blog/blog-list')?>
</section>
<?php get_footer(); ?>