<?php get_header(); ?>

    <section>
        <div class="container">
            <?php get_template_part('loop'); ?>
        </div>
    </section>

<?php get_footer(); ?>