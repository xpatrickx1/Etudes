<div class="top-screen">
    <div class="container">
        <div class="top-screen__wrap">

            <img src="<?= bloginfo('template_url') . '/images/projects/projects.svg' ?>"
                alt="Back to homepage logo link"
                width="716"
                height="226"
            >
        </div>
    </div>
</div>