

<div class="preloader" id="preloader">
    <div class="preloader__progress"></div>
    <div class="container">
        <div class="preloader__loading">
            <img src="<?= bloginfo('template_url') . '/images/loading.svg' ?>"
                alt="Back to homepage logo link"
                width="716"
                height="226"
            >
        </div>  
    </div>
</div>