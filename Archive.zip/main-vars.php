<?php
// *********************** |Main php variables| ***************************
$phoneTel = "";


$nameDomain = $_SERVER['HTTP_HOST'];
$currency = "€";

?>
