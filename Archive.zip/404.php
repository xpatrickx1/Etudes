<?php get_header(); ?>
    <div class="error-page">
        <h2 class="error-page__404">404</h2>
        <div class="error-page__text">
            <p>Page not found</p>
            <p>Visit the <a href="/">Homepage</a></p>
        </div>
    </div>
<?php get_footer(); ?>