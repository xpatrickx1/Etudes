
<?php
/* Template Name: About Template */
?>

<?php get_header(); ?>
<div class='cd-main-content cd-about'>
  <?php get_template_part('includes/sections/page-about/top-screen')?>
  <?php get_template_part('includes/sections/page-about/team')?>
    
</section>
<?php get_footer(); ?>
