

<?php get_header(); ?>
<?php get_template_part('includes/sections/page-front/preloader')?>
<section class="top-screen cd-index cd-main-content">
<?php get_template_part('includes/sections/page-front/top-screen')?>
</section>
<?php get_footer(); ?>