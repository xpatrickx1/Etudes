
<?php /* Template Name: Front page */?>


<?php get_template_part('pages/page-front')?>
