<?php
/* Template Name: SEO Page */
get_header();

?>

<?php get_template_part('includes/sections/page-blog/top-screen')?>
<?php get_template_part('includes/sections/page-blog/blog-list')?>

<?php
get_footer();
?>